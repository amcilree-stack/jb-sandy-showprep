#!/usr/bin/env python3
"""
Core audio extraction logic for JB & Sandy Audio Extractor.
Uses yt-dlp + ffmpeg.
"""

import os
import re
import json
import subprocess
import sys
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).parent.resolve()
OUTPUT_DIR = BASE_DIR / "output"
HISTORY_FILE = BASE_DIR / "history" / "recent.json"

# Common Windows locations for ffmpeg
FFMPEG_CANDIDATES = [
    r"C:\Users\The Sandy Show\AppData\Local\Microsoft\WinGet\Links",
    r"C:\Program Files (x86)\Common Files\AutoPod\ffmpeg\bin",
    r"C:\Program Files\ffmpeg\bin",
    r"C:\ffmpeg\bin",
    str(BASE_DIR),  # also look in the tool folder itself
]


def find_ffmpeg_dir() -> str | None:
    """Return a directory that contains ffmpeg.exe, or None."""
    for folder in FFMPEG_CANDIDATES:
        exe = Path(folder) / "ffmpeg.exe"
        if exe.exists():
            return folder
    # Also try whatever is already on PATH
    try:
        r = subprocess.run(["where", "ffmpeg"], capture_output=True, text=True)
        if r.returncode == 0 and r.stdout.strip():
            return str(Path(r.stdout.strip().splitlines()[0]).parent)
    except Exception:
        pass
    return None


def ensure_dirs():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not HISTORY_FILE.exists():
        HISTORY_FILE.write_text("[]", encoding="utf-8")


def sanitize_filename(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*]', "", name)
    name = re.sub(r"\s+", " ", name).strip()
    return name[:120] if name else "audio"


def load_history() -> list:
    ensure_dirs()
    try:
        return json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
    except Exception:
        return []


def save_history(entries: list):
    ensure_dirs()
    entries = entries[:30]
    HISTORY_FILE.write_text(json.dumps(entries, indent=2), encoding="utf-8")


def add_to_history(url: str, filepath: str, title: str, custom_name: str | None = None):
    history = load_history()
    entry = {
        "url": url,
        "filepath": str(filepath),
        "filename": Path(filepath).name,
        "title": title or Path(filepath).stem,
        "custom_name": custom_name,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
    }
    history.insert(0, entry)
    save_history(history)


def extract_one(url: str, custom_name: str | None = None, quality: str = "0") -> dict:
    ensure_dirs()

    if custom_name:
        safe = sanitize_filename(custom_name)
        outtmpl = str(OUTPUT_DIR / f"{safe}.%(ext)s")
    else:
        outtmpl = str(OUTPUT_DIR / "%(title).100B [%(id)s].%(ext)s")

    # Use python -m yt_dlp so we don't depend on a yt-dlp.exe being on PATH
    cmd = [
        sys.executable, "-m", "yt_dlp",
        "-x",
        "--audio-format", "mp3",
        "--audio-quality", quality,
        "--no-playlist",
        "--embed-thumbnail",
        "--add-metadata",
        "--no-mtime",
        "-o", outtmpl,
        "--print", "after_move:filepath",
        "--print", "before_dl:title",
        url,
    ]

    # Point yt-dlp at ffmpeg if we can find it
    ffmpeg_dir = find_ffmpeg_dir()
    if ffmpeg_dir:
        cmd.extend(["--ffmpeg-location", ffmpeg_dir])

    # Also put it on PATH for this process
    env = os.environ.copy()
    if ffmpeg_dir:
        env["PATH"] = ffmpeg_dir + os.pathsep + env.get("PATH", "")

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=180,
            check=False,
            env=env,
        )

        stdout_lines = [l.strip() for l in result.stdout.splitlines() if l.strip()]
        stderr = result.stderr or ""

        if result.returncode != 0:
            err_lines = [l for l in stderr.splitlines() if l.strip()]
            useful = err_lines[-5:] if err_lines else ["Unknown error"]
            # Make the error more helpful
            err_text = "\n".join(useful)
            if "WinError 2" in err_text or "cannot find the file" in err_text.lower():
                err_text += "\n\n→ ffmpeg still not being found. Try copying ffmpeg.exe into the tool folder."
            return {
                "success": False,
                "url": url,
                "error": err_text,
                "filepath": None,
                "title": None,
            }

        filepath = None
        title = None
        for line in reversed(stdout_lines):
            if line.lower().endswith(".mp3") and Path(line).exists():
                filepath = line
                break
        if len(stdout_lines) >= 2:
            title = stdout_lines[0] if not stdout_lines[0].lower().endswith(".mp3") else None

        if not filepath or not Path(filepath).exists():
            mp3s = sorted(OUTPUT_DIR.glob("*.mp3"), key=lambda p: p.stat().st_mtime, reverse=True)
            if mp3s:
                filepath = str(mp3s[0])
            else:
                return {
                    "success": False,
                    "url": url,
                    "error": "Download finished but could not find the MP3 file.\n" + (stderr[-300:] if stderr else ""),
                    "filepath": None,
                    "title": title,
                }

        final_path = Path(filepath)
        add_to_history(url, str(final_path), title or final_path.stem, custom_name)

        return {
            "success": True,
            "url": url,
            "filepath": str(final_path),
            "filename": final_path.name,
            "title": title or final_path.stem,
            "error": None,
        }

    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "url": url,
            "error": "Timed out (video may be too long or platform is slow).",
            "filepath": None,
            "title": None,
        }
    except Exception as e:
        return {
            "success": False,
            "url": url,
            "error": str(e),
            "filepath": None,
            "title": None,
        }


def extract_many(urls: list[str], custom_name: str | None = None) -> list[dict]:
    results = []
    name = custom_name if len(urls) == 1 else None
    for url in urls:
        url = url.strip()
        if not url:
            continue
        results.append(extract_one(url, custom_name=name))
    return results
