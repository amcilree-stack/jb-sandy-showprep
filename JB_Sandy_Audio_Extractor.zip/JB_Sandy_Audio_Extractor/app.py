#!/usr/bin/env python3
"""
JB & Sandy Audio Extractor - Local Web UI
Run this on your Windows or Mac computer.
"""

import os
import sys
import zipfile
import tempfile
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_file, send_from_directory

# Make sure we can import from the same folder
sys.path.insert(0, str(Path(__file__).parent))

from extract_audio import extract_many, load_history, OUTPUT_DIR, ensure_dirs

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024  # small form data only

BASE_DIR = Path(__file__).parent.resolve()


@app.route("/")
def index():
    history = load_history()
    return render_template("index.html", history=history[:12])


@app.route("/extract", methods=["POST"])
def extract():
    data = request.get_json(force=True, silent=True) or {}
    raw = data.get("urls", "") or ""
    custom_name = (data.get("name") or "").strip() or None

    # Split on newlines or commas
    urls = []
    for line in raw.replace(",", "\n").splitlines():
        line = line.strip()
        if line.startswith("http"):
            urls.append(line)

    if not urls:
        return jsonify({"ok": False, "error": "No valid URLs found. Paste one or more links that start with http."})

    if len(urls) > 8:
        return jsonify({"ok": False, "error": "Please limit to 8 URLs at a time for reliability."})

    results = extract_many(urls, custom_name=custom_name)
    return jsonify({"ok": True, "results": results})


@app.route("/download/<path:filename>")
def download_file(filename):
    # Security: only allow files from the output folder
    safe = Path(filename).name
    path = OUTPUT_DIR / safe
    if not path.exists() or not path.is_file():
        return "File not found", 404
    return send_file(path, as_attachment=True, download_name=safe)


@app.route("/download-zip", methods=["POST"])
def download_zip():
    data = request.get_json(force=True, silent=True) or {}
    filenames = data.get("files", [])
    if not filenames:
        return jsonify({"ok": False, "error": "No files selected"}), 400

    # Create a temporary zip
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".zip")
    tmp.close()

    with zipfile.ZipFile(tmp.name, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in filenames:
            safe = Path(name).name
            path = OUTPUT_DIR / safe
            if path.exists():
                zf.write(path, arcname=safe)

    return send_file(
        tmp.name,
        as_attachment=True,
        download_name="JB_Sandy_Audio_Extracts.zip",
        mimetype="application/zip",
    )


@app.route("/history")
def history_api():
    return jsonify(load_history()[:20])


@app.route("/open-output")
def open_output():
    """Helper – just tells the user where files are."""
    return jsonify({"path": str(OUTPUT_DIR)})


if __name__ == "__main__":
    ensure_dirs()
    print("\n" + "=" * 55)
    print("  JB & Sandy Audio Extractor")
    print("  Open this address in your browser:")
    print("  →  http://127.0.0.1:5055")
    print("=" * 55 + "\n")
    # Use 5055 to avoid common conflicts
    app.run(host="127.0.0.1", port=5055, debug=False)
