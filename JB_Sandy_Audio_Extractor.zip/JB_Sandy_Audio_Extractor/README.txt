JB & SANDY AUDIO EXTRACTOR
===========================

Simple local tool that turns social media video links into MP3s.
Works on Windows and Mac.

--------------------------------------------------
FIRST-TIME SETUP (do this once on each computer)
--------------------------------------------------

1. Make sure Python 3 is installed
   - Windows: https://www.python.org/downloads/  
     (IMPORTANT: check the box "Add Python to PATH")
   - Mac: usually already present, or install from python.org / Homebrew

2. Copy this whole folder to the computer
   (Desktop or Documents is fine)

3. Double-click the correct starter:
   - Windows →  Start_Windows.bat
   - Mac     →  Start_Mac.command
     (First time on Mac you may need to right-click → Open)

4. Your browser will open to http://127.0.0.1:5055

--------------------------------------------------
HOW TO USE
--------------------------------------------------

1. Paste one or more video URLs into the big box
2. (Optional) Type a custom filename if you are doing a single link
3. Click "Extract Audio"
4. When it finishes, click Download MP3
5. Recent extractions appear at the bottom for easy re-download

Files are saved in the "output" folder inside this tool folder.

--------------------------------------------------
TIPS
--------------------------------------------------

• YouTube links work most reliably
• Instagram and Facebook sometimes fail (they block downloads)
• Keep the black/terminal window open while using the tool
• Close the terminal window (or press Ctrl+C) when you are finished

--------------------------------------------------
NEED HELP?
--------------------------------------------------

Ask Sandy or drop the error message into the Grok chat.
