@echo off
title JB & Sandy Audio Extractor
cd /d "%~dp0"

echo.
echo  ========================================
echo   JB ^& Sandy Audio Extractor
echo  ========================================
echo.

REM Check for Python
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python is not installed or not in PATH.
    echo.
    echo  Please install Python 3 from:
    echo  https://www.python.org/downloads/
    echo.
    echo  IMPORTANT: During install, check the box that says
    echo  "Add Python to PATH"
    echo.
    pause
    exit /b 1
)

echo  Python found.
echo  Installing/updating required tools...

python -m pip install --user -q --upgrade yt-dlp flask 2>nul

REM -------------------------------------------------------
REM Make sure ffmpeg is findable (common Windows locations)
REM -------------------------------------------------------
set "PATH=%PATH%;C:\Users\The Sandy Show\AppData\Local\Microsoft\WinGet\Links"
set "PATH=%PATH%;C:\Program Files (x86)\Common Files\AutoPod\ffmpeg\bin"
set "PATH=%PATH%;C:\Program Files\ffmpeg\bin"
set "PATH=%PATH%;C:\ffmpeg\bin"

REM Also check if ffmpeg is already callable
ffmpeg -version >nul 2>&1
if errorlevel 1 (
    echo.
    echo  [WARNING] ffmpeg still not found in PATH.
    echo  The tool will try anyway...
    echo.
) else (
    echo  ffmpeg found and ready.
)

echo  All tools ready.
echo.
echo  Opening http://127.0.0.1:5055 in your browser...
echo  Keep this window open while you use the tool.
echo  Press Ctrl+C to stop.
echo.

start "" http://127.0.0.1:5055
python app.py

echo.
pause
