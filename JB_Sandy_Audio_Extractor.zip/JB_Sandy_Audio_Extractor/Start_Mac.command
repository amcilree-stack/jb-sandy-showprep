#!/bin/bash
cd "$(dirname "$0")"

echo ""
echo "  Starting JB & Sandy Audio Extractor..."
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "  Python 3 is not installed."
    echo "  Install it from https://www.python.org/downloads/ or with: brew install python"
    echo ""
    read -p "  Press Enter to close..."
    exit 1
fi

# Install deps quietly if needed
python3 -m pip install --user -q yt-dlp flask 2>/dev/null

echo "  Opening http://127.0.0.1:5055 in your browser..."
echo "  Keep this window open while you use the tool."
echo "  Press Ctrl+C to stop."
echo ""

# Open browser
open "http://127.0.0.1:5055" 2>/dev/null || true

python3 app.py
